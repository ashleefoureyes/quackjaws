#include "Control.h"

int main()
{
    Control cont;
    cont.launch();
}