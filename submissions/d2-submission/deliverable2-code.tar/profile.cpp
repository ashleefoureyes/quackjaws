#include "profile.h"

Profile::Profile()
{
}

int Profile::getId() { return this->profileId; }
